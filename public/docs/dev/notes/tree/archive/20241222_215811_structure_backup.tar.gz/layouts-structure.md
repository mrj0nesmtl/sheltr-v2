# 🌳 SHELTR Layouts Structure
*Generated: 2024-12-22 21:58:11*
\n## Directory Structure
./src/layouts
├── base
│   ├── Layout.tsx
│   └── PageLayout.tsx
├── components
│   └── Header.tsx
├── specialized
│   └── dashboard
│       ├── Sidebar
│       ├── components
│       └── index.ts
├── PageLayout.tsx
├── index.ts
└── types.ts

7 directories, 7 files
