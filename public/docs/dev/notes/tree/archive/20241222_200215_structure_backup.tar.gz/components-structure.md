# 🌳 SHELTR Components Structure
*Generated: 2024-12-22 20:02:15*
\n## Directory Structure
./src/components
├── About
│   ├── sections
│   │   ├── Checkpoint.tsx
│   │   ├── Introduction.tsx
│   │   ├── Roadmap.tsx
│   │   ├── TechStack.tsx
│   │   ├── Whitepaper.tsx
│   │   └── index.ts
│   ├── CallToAction.tsx
│   ├── Features.tsx
│   ├── MarkdownContent.tsx
│   ├── ProjectStatus.tsx
│   └── StatusCard.tsx
├── Admin
│   ├── Analytics
│   │   ├── ShelterMap.tsx
│   │   ├── ShelterOverview.tsx
│   │   ├── ShelterStats.tsx
│   │   └── ShelterTable.tsx
│   ├── Shelters
│   │   └── ShelterList.tsx
│   ├── DonationMap.tsx
│   ├── DonorList.tsx
│   ├── FundAllocationChart.tsx
│   ├── ParticipantLeaderboard.tsx
│   ├── ParticipantList.tsx
│   ├── ParticipantManagementTable.tsx
│   ├── ParticipantRegistration.tsx
│   ├── ParticipantRegistrationModal.tsx
│   ├── ParticipantRow.tsx
│   ├── QRAnalytics.tsx
│   └── SystemAlerts.tsx
├── Analytics
│   ├── DonationTrends.tsx
│   └── TransactionTable.tsx
├── Auth
│   ├── forms
│   │   ├── DonorSignUpForm.tsx
│   │   ├── ShelterSignUpForm.tsx
│   │   └── index.ts
│   ├── AuthLayout.tsx
│   ├── LoginButton.tsx
│   ├── LoginForm.tsx
│   ├── ShelterRegistrationForm.tsx
│   ├── SignUpForm.tsx
│   └── SignUpSelector.tsx
├── Blockchain
│   ├── Whitepaper
│   │   └── WhitepaperLayout.tsx
│   ├── BlockchainStats.tsx
│   ├── TransactionList.tsx
│   ├── WhitepaperPage.tsx
│   └── index.ts
├── Blog
│   ├── BlogEditor.tsx
│   ├── BlogList.tsx
│   └── BlogPost.tsx
├── Contact
│   └── ContactForm.tsx
├── CustomerSupport
│   ├── CustomerSupport.tsx
│   └── index.ts
├── Dashboard
│   ├── Analytics
│   │   ├── DonationHistory.tsx
│   │   ├── DonorStats.tsx
│   │   └── StatCard.tsx
│   ├── DonorLeaderboard.tsx
│   └── ParticipantRow.tsx
├── Documentation
│   ├── components
│   │   ├── DocViewer.tsx
│   │   ├── DocumentHub.tsx
│   │   ├── DocumentViewer.tsx
│   │   ├── TableOfContents.tsx
│   │   ├── WhitepaperView.tsx
│   │   └── index.ts
│   ├── pages
│   │   └── WhitepaperPage.tsx
│   ├── MarkdownViewer.tsx
│   └── index.ts
├── DonationForm
│   └── DonationForm.tsx
├── ErrorBoundary
│   ├── BaseErrorBoundary.tsx
│   ├── ParticipantErrorBoundary.tsx
│   ├── ShelterAdminErrorBoundary.tsx
│   └── index.ts
├── Footer
│   ├── Footer.tsx
│   └── index.ts
├── Hero
│   └── Hero.tsx
├── HowItWorks
│   └── index.ts
├── Layout
│   └── index.tsx
├── Legal
│   ├── PrivacyPolicy.tsx
│   └── TermsOfService.tsx
├── Map
│   └── DonationMap.tsx
├── Meta
│   └── PageMeta.tsx
├── Navigation
│   ├── MobileMenu.tsx
│   ├── MobileNav.tsx
│   ├── Navigation.tsx
│   ├── UserMenu.tsx
│   ├── UserNav.tsx
│   └── types.ts
├── Participant
├── Podcast
│   └── PodcastPreview.tsx
├── Profile
│   ├── ActivityLog.tsx
│   ├── AddFriend.tsx
│   ├── AdminFeatures.tsx
│   ├── BaseProfile.tsx
│   ├── DonorFeatures.tsx
│   ├── EditProfileModal.tsx
│   ├── FriendActivity.tsx
│   ├── ImageCropModal.tsx
│   ├── ImageUpload.tsx
│   ├── ParticipantFeatures.tsx
│   ├── ProfileLayout.tsx
│   ├── RoleSpecificInfo.tsx
│   ├── SocialLinks.tsx
│   └── UserProfile.tsx
├── QRScanner
│   ├── QRScanner.tsx
│   └── QRScannerLoading.tsx
├── SEO
│   └── MetaTags.tsx
├── Settings
│   └── BaseSettings.tsx
├── Sidebar
│   └── Sidebar.tsx
├── SuperAdmin
│   ├── AlertsAndIncidents.tsx
│   ├── DonationAnalytics.tsx
│   ├── NotificationCenter.tsx
│   ├── QuickStatCard.tsx
│   ├── ShelterPerformanceChart.tsx
│   └── SystemHealthMonitor.tsx
├── ThankYou
│   └── ThankYou.tsx
├── Token
│   └── TokenPage.tsx
├── Transactions
│   └── TransactionList.tsx
├── UserBadge
│   └── UserBadge.tsx
├── Verify
│   └── VerifyPage.tsx
├── layouts
│   └── index.ts
├── ui
│   ├── Charts
│   │   ├── AreaChart.tsx
│   │   ├── BarChart.tsx
│   │   ├── LineChart.tsx
│   │   └── index.ts
│   ├── Accordion.tsx
│   ├── Avatar.tsx
│   ├── Badge.tsx
│   ├── Button.tsx
│   ├── Card.tsx
│   ├── Checkbox.tsx
│   ├── CustomIcons.tsx
│   ├── FeatureCard.tsx
│   ├── FullContentModal.tsx
│   ├── Icon.tsx
│   ├── ImageUpload.tsx
│   ├── Input.tsx
│   ├── LanguageToggle.tsx
│   ├── LoadingOverlay.tsx
│   ├── LoadingSpinner.tsx
│   ├── Logo.tsx
│   ├── NavLink.tsx
│   ├── ProfileMenu.tsx
│   ├── QRCode.tsx
│   ├── Select.tsx
│   ├── SignOutButton.tsx
│   ├── StatCard.tsx
│   ├── Textarea.tsx
│   ├── Toast.tsx
│   ├── Toaster.tsx
│   └── index.ts
├── ErrorBoundary.tsx
├── Hero.tsx
├── Logo.tsx
└── ThemeToggle.tsx

45 directories, 149 files
