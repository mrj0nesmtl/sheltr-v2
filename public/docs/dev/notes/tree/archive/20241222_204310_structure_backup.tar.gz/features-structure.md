# 🌳 SHELTR Features Structure
*Generated: 2024-12-22 20:43:11*
\n## Directory Structure
./src/features
├── auth
│   ├── components
│   │   └── index.ts
│   ├── hooks
│   ├── store
│   ├── utils
│   └── index.ts
├── dashboard
│   ├── components
│   │   └── index.ts
│   ├── hooks
│   ├── store
│   ├── utils
│   └── index.ts
├── donor
│   ├── components
│   │   └── DonorDashboard.tsx
│   ├── types
│   │   └── donor.ts
│   └── validation
│       └── donorValidation.ts
├── profile
│   ├── components
│   │   └── index.ts
│   ├── hooks
│   ├── store
│   ├── utils
│   └── index.ts
├── roles
│   ├── donor
│   │   ├── components
│   │   ├── hooks
│   │   ├── store
│   │   ├── utils
│   │   └── index.ts
│   ├── participant
│   │   ├── components
│   │   ├── hooks
│   │   ├── store
│   │   ├── utils
│   │   └── index.ts
│   ├── shelter-admin
│   │   ├── components
│   │   ├── hooks
│   │   ├── store
│   │   ├── utils
│   │   └── index.ts
│   └── super-admin
│       ├── components
│       ├── hooks
│       ├── store
│       ├── utils
│       └── index.ts
└── shared
    ├── analytics
    ├── components
    │   └── index.ts
    ├── hooks
    ├── store
    ├── utils
    └── index.ts

47 directories, 15 files
