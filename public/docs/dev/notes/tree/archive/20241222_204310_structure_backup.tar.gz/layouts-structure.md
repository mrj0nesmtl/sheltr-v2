# 🌳 SHELTR Layouts Structure
*Generated: 2024-12-22 20:43:11*
\n## Directory Structure
./src/layouts
├── base
│   ├── Layout.tsx
│   └── PageLayout.tsx
├── components
│   └── Header.tsx
├── specialized
│   └── dashboard
│       ├── Sidebar
│       ├── components
│       ├── DashboardLayout.tsx
│       └── index.ts
├── PageLayout.tsx
├── index.ts
└── types.ts

7 directories, 8 files
